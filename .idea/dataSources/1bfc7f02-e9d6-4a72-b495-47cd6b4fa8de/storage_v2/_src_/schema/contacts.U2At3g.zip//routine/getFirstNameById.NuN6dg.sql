CREATE FUNCTION getFirstNameById(in_id INT)
  RETURNS VARCHAR(60)
  BEGIN 
	RETURN (select first_name from contact where c_id = in_id) ;
END;

